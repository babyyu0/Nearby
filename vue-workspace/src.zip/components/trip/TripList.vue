<template>
	<div class="container mt-5">	
		<div class="display-3 mb-5 text-center">관광지 정보 목록</div>
		<div id="region-container" class="row mb-3">
			<div class="col-4"><select id="select-sido" class="form-select" onchange="changeGugun();getTripList(1);"></select></div>
			<div class="col-4"><select id="select-gugun" class="form-select" onchange="getTripList(1)"></select></div>
			<div class="col-4"><select id="select-trip-type" class="form-select" onchange="getTripList(1)"></select></div>
		</div>
		<div id="map-container">
			<div id="map" class="mx-auto" style="height:500px"></div>
		</div>
		<div id="list-container" class="">
			<table class="table">
				<thead>
					<tr>
						<th scope="col-1">#</th>
						<th scope="col-3">이름</th>
						<th scope="col-8">주소</th>
					</tr>
				</thead>
				<tbody id="list-body"></tbody>
			</table>
			<div aria-label="Page navigation example">
				<ul id="pagination" class="pagination justify-content-center"></ul>
			</div>
		</div>
	</div>
</template>