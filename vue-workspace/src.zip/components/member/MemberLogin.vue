<template>
    <b-container align-v="center">
        <h1 class="mt-5 text-center">로그인</h1>
        <b-card-group class="justify-content-center">
        <b-card class="mt-4" style="max-width: 40rem;">
            <b-form-input class="mt-4" placeholder="아이디"></b-form-input>
            <b-form-input class="mt-2" placeholder="비밀번호"></b-form-input>
            <div class="mt-4 text-center">
                <b-button button-right variant="primary">로그인</b-button>
                <b-card-text class="mt-2 text-center">
                    회원가입
                </b-card-text>
            </div>
        </b-card>
    </b-card-group>
    </b-container>
</template>
<script>

export default {
    data() {
        return {};
    },
    components: {}
}
</script>