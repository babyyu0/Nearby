<template>
  <router-view />
</template>

<script>
export default {
  name: 'MemberView',
}
</script>
  