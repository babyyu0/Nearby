<template>
  <div>
    <b-jumbotron header="✈️ Enjoy Trip!" lead="Enjoy trip에서 당신의 여행지를 찾아보세요!">
      <!-- <p>For more information visit website</p> -->
      <b-button class="btn-lg" variant="primary" to="/trip">관광지 찾기</b-button>
    </b-jumbotron>
  </div>
</template>

<script>
export default {
  name: 'HomeView',
}
</script>
